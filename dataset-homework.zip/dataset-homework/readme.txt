This dataset was downloaded from the following 10X Genomics link:

https://support.10xgenomics.com/single-cell-gene-expression/datasets/2.1.0/neurons_2000

and selecting "Gene / cell matrix (filtered)".
